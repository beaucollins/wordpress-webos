enyo.kind({
  name: 'AccountTabs',
  kind: 'enyo.Control',
  layoutKind: 'VFlexLayout'
});