
enyo.depends(
	"wp/WordPress.js",
	"wp/SourceList.js",
	"wp/AccountListItem.js",
	"css/WordPress.css",
	"lib/md5.js",
	"lib/XMLRPCService.js",
	"lib/WordPressService.js",
	"lib/SimpleHtmlParser.js",
	"ui/AccountList.js",
	"ui/AccountSetup.js",
	"ui/AccountTabs.js"
);